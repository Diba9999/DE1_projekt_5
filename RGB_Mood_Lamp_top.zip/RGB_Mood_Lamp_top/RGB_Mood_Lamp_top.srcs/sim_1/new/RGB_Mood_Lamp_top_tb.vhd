library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_RGB_Mood_Lamp_top is
-- Testbench pro top level nemá porty
end tb_RGB_Mood_Lamp_top;

architecture behavior of tb_RGB_Mood_Lamp_top is

    -- Deklarace Top-Level komponenty
    component RGB_Mood_Lamp_top
        Port ( 
            clk     : in STD_LOGIC;
            btnc    : in STD_LOGIC;
            btnu    : in STD_LOGIC;
            btnd    : in STD_LOGIC;
            btnl    : in STD_LOGIC;
            btnr    : in STD_LOGIC;
            led17_r : out STD_LOGIC;
            led17_g : out STD_LOGIC;
            led17_b : out STD_LOGIC;
            seg     : out STD_LOGIC_VECTOR(6 downto 0);
            an      : out STD_LOGIC_VECTOR(1 downto 0)
        );
    end component;

    -- Vstupní signály
    signal clk  : std_logic := '0';
    signal btnc : std_logic := '0';
    signal btnu : std_logic := '0';
    signal btnd : std_logic := '0';
    signal btnl : std_logic := '0';
    signal btnr : std_logic := '0';

    -- Výstupní signály
    signal led17_r : std_logic;
    signal led17_g : std_logic;
    signal led17_b : std_logic;
    signal seg     : std_logic_vector(6 downto 0);
    signal an      : std_logic_vector(1 downto 0);

    -- Konstanty pro časování
    constant clk_period : time := 10 ns;
    
    -- Doba stisku musí překonat debouncer (>10 ms)
    constant BTN_PRESS_TIME : time := 20 ms; 

begin

    -- Instancování testovaného modulu (DUT)
    uut: RGB_Mood_Lamp_top
        port map (
            clk     => clk,
            btnc    => btnc,
            btnu    => btnu,
            btnd    => btnd,
            btnl    => btnl,
            btnr    => btnr,
            led17_r => led17_r,
            led17_g => led17_g,
            led17_b => led17_b,
            seg     => seg,
            an      => an
        );

    -- Generování hodinového signálu (100 MHz)
    clk_process :process
    begin
        clk <= '0';
        wait for clk_period/2;
        clk <= '1';
        wait for clk_period/2;
    end process;

    -- Hlavní testovací proces s využitím procedury pro tlačítka
    stim_proc: process
        
        -- Procedura pro zjednodušení simulace stisku tlačítka
        procedure press_btn(signal btn : out std_logic) is
        begin
            btn <= '1';
            wait for BTN_PRESS_TIME; -- Doba stisku
            btn <= '0';
            wait for 5 ms;           -- Pauza na uvolnění a ustálení
        end procedure;

    begin
        -- 1. Reset systému (stisk BTNC)
        btnc <= '1';
        wait for 100 ns;
        btnc <= '0';
        wait for 1 ms;

        -- Výchozí stav by měl být: MODE = SET_BRIGHTNESS, jas = 6, rychlost = 5

        -- ==========================================
        -- 2. TEST REŽIMU JASU (Brightness)
        -- ==========================================
        -- Zvýšení jasu o 2 kroky (z 6 na 8)
        press_btn(btnu);
        press_btn(btnu);
        
        -- Snížení jasu o 1 krok (z 8 na 7)
        press_btn(btnd);

        -- ==========================================
        -- 3. TEST PŘEPNUTÍ REŽIMU (BTNR -> Speed)
        -- ==========================================
        press_btn(btnr);

        -- ==========================================
        -- 4. TEST REŽIMU RYCHLOSTI (Speed)
        -- ==========================================
        -- Zvýšení rychlosti o 1 krok (z 5 na 6)
        press_btn(btnu);

        -- Snížení rychlosti o 3 kroky (z 6 na 3)
        press_btn(btnd);
        press_btn(btnd);
        press_btn(btnd);
        
        -- ==========================================
        -- 5. TEST NÁVRATU DO REŽIMU JASU (BTNL)
        -- ==========================================
        press_btn(btnl);

        -- 6. Pozorování plynulé změny barev a PWM
        -- Necháme běžet dostatečně dlouho, aby FSM odpočítal pauzy
        wait for 50 ms; 

        -- Konec simulace
        std.env.stop;
    end process;

end behavior;